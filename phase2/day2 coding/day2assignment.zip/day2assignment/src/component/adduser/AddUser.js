import axios from "axios";
import { useEffect, useState } from "react";
import Menu from "../menu/Menu";
const AddUser = () => { 
  const [data, setData] = useState({
    username : '',
    password : '',
    name : '',
    city : '',
    project : ''
})
const handleChange = event => {
    setData({
        ...data,[event.target.name] : event.target.value  
    })
}
const AddUser = () => {
  axios.post("http://localhost:2222/adduser",{
    username : data.username,
    password : data.password,
    name : data.name,
    city : data.city ,
    project : data.project,
  }).then(resp => {
    alert("User added successfully");
    console.log(resp.data);
  })
}
return(
  <div>
    <Menu/>
      <label>Username : </label>
      <input type="text" name="username" 
          value={data.username} onChange={handleChange} /> <br/><br/>
          <label>Password : </label>
          <input type="password" name="password" 
          value={data.password} onChange={handleChange} /> <br/><br/>
      <label>Name : </label>
      <input type="text" name="name" 
          value={data.name} onChange={handleChange} /> <br/><br/> 
          <label>City : </label>
      <input type="text" name="city" 
          value={data.city} onChange={handleChange} /> <br/><br/> <label>Project : </label>
          <input type="text" name="project" 
              value={data.project} onChange={handleChange} /> <br/><br/> 
      
      <input type="button" value="Add User" onClick={AddUser} /> 
   </div>
)
}
export default AddUser;