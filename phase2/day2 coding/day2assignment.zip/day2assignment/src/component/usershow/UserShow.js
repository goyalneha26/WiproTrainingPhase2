import axios from "axios";
import { useEffect, useState } from "react";
import Menu from "../menu/Menu";
const UserShow = () => { 
    const [users,setUserData] = useState([])
    useEffect(()=>{
        const fetchData = async () => {
            const response = await axios.get("http://localhost:2222/showuser");
            setUserData(response.data)
        };
        fetchData()
    },[])
    return(
      <>
    <Menu/>
      
        <table border="3" align="center">
          <tr>
            <th>User Id</th>
            <th>Username</th>
            <th>Password</th>
            <th>Name</th>
            <th>City</th>
            <th>Project</th>
          </tr>
          {users.map((item) => 
            <tr>
              <td>{item.userid}</td>
              <td>{item.username}</td>
              <td>{item.password}</td>
              <td>{item.name}</td>
              <td>{item.city}</td>
              <td>{item.project}</td>
              
            </tr>
          )}
        </table>
        </>
      )
}
export default UserShow;