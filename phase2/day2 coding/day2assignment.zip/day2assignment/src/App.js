import logo from './logo.svg';
import './App.css';
import AddUser from './component/adduser/AddUser';
import Menu from './component/menu/Menu';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import UserShow from './component/usershow/UserShow';

function App() {
  return (
    <div className="App">
      <BrowserRouter>

<Routes>

  {/* <Route path="/" element={<Login />} /> */}
  <Route path="/" element={<Menu />} />

  <Route path="/adduser" element={<AddUser />} />
  <Route path="/showuser" element={<UserShow />} />
  {/* <Route path="/employeeshow" element={<EmpoyeeShow />} />
  <Route path="/postshow" element={<PostShow />} />
  <Route path="/searchemployee" element={<EmploySearch />} /> 
  <Route path="/searchjson" element={<JsonSearch />} />
  <Route path="/usershow" element={<UserShow />} /> */}
</Routes>
</BrowserRouter>
    </div>
  );
}

export default App;
