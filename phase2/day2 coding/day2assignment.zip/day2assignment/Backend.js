var express = require("express");
var bodyParser = require("body-parser");
var cors = require("cors");
var app = express();

app.use(bodyParser.json());
app.use(cors());

let users = [
    {"userid": 1, "username": "Ashish", "password": "Ashish", "name": "Ashish Kumar", "city": "Delhi", "project": "Inventory Management"},
    {"userid": 2, "username": "Sravani", "password": "SaiSrav", "name": "Sravani Reddy", "city": "Hyderabad", "project": "E-commerce Website"},
    {"userid": 3, "username": "Neha", "password": "Goyal", "name": "Neha Goyal", "city": "Mumbai", "project": "Banking System"},
    {"userid": 4, "username": "Isha", "password": "Ghosh", "name": "Isha Ghosh", "city": "Kolkata", "project": "CRM Software"},
];

app.get("/showuser", (req, res) => {
    res.status(200).json(users);
});

app.post('/adduser', function (req, res) {
    let newItem = {
        userid: users.length + 1, // Auto-increment user ID
        username: req.body.username,
        password: req.body.password,
        name: req.body.name,
        city: req.body.city,
        project: req.body.project,
    };

    users.push(newItem);
    res.status(201).json({ 'message': "User successfully created", 'user': newItem });
});

app.get("/searchuser/:username", (req, res) => {
    let found = users.find(user => user.username === req.params.username);
    if (found) {
        res.status(200).json(found);
    } else {
        res.sendStatus(404);
    }
});

// Route to validate username and password
app.get("/validate/:username/:password", (req, res) => {
    let { username, password } = req.params;
    let found = users.find(user => user.username === username && user.password === password);
    
    if (found) {
        res.status(200).json({ message: "Validation successful", user: found });
    } else {
        res.status(401).json({ message: "Invalid username or password" });
    }
});

app.listen(2222, () => {
    console.log("Node Js Application Started on port 2222");
});