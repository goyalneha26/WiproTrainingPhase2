import logo from './logo.svg';
import './App.css';
import StockDashboard from './Components/StockDashboard';

function App() {
  return (
    <div className="App">
      <StockDashboard/>
    </div>
  );
}

export default App;
