// React Frontend (StockDashboard.js) - Search Button Only
import React, { Component } from 'react';
import io from 'socket.io-client';
import 'bootstrap/dist/css/bootstrap.min.css';
import './StockDashboard.css';

class StockDashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      stockSymbol: '',
      stockPrice: null,
      previousSearches: [],
      socket: null,
      theme: 'light',
      socketConnected: false,
      receivedData: null,
    };
    this.stockSymbolInput = React.createRef();
  }

  componentDidMount() {
    this.setupSocket();
  }

  componentWillUnmount() {
    if (this.state.socket) {
      this.state.socket.disconnect();
    }
  }

  setupSocket = () => {
    const socket = io('http://localhost:5000');
    socket.on('connect', () => {
      console.log('Socket connected');
      this.setState({ socketConnected: true });
    });

    socket.on('stockUpdate', (data) => {
      console.log('Received stock update:', data);
      this.setState({ receivedData: data });

      if (data.symbol === this.state.stockSymbol) {
        this.setState({ stockPrice: data.price });
      }
    });

    socket.on('disconnect', () => {
      console.log('Socket disconnected');
      this.setState({ socketConnected: false });
    });

    this.setState({ socket });
  };

  fetchStockData = (symbol) => {
    if (this.state.socket) {
      this.state.socket.emit('getStockPrice', symbol);
      console.log(`Emitting getStockPrice for: ${symbol}`);
    }
  };

  handleInputChange = (event) => {
    this.setState({ stockSymbol: event.target.value });
  };

  handleSearch = () => {
    if (this.state.stockSymbol) {
      this.setState((prevState) => ({
        previousSearches: [...prevState.previousSearches, this.state.stockSymbol],
      }));
      this.fetchStockData(this.state.stockSymbol);
      this.stockSymbolInput.current.value = this.state.stockSymbol;
    }
  };

  toggleTheme = () => {
    this.setState((prevState) => ({
      theme: prevState.theme === 'light' ? 'dark' : 'light',
    }));
  };

  render() {
    const {
      stockSymbol,
      stockPrice,
      previousSearches,
      theme,
      socketConnected,
      receivedData,
    } = this.state;
    const themeClass = theme === 'dark' ? 'dark-theme' : 'light-theme';

    return (
      <div className={`container mt-5 ${themeClass}`}>
        <h1>Real-Time Stock Dashboard</h1>
        <button className="btn btn-secondary mb-3" onClick={this.toggleTheme}>
          Toggle Theme
        </button>
        <div className="mb-3">
          <strong>Socket Connection:</strong> {socketConnected ? 'Connected' : 'Disconnected'}
        </div>
        <div className="input-group mb-3">
          <input
            type="text"
            className="form-control"
            placeholder="Enter Stock Symbol (e.g., AAPL)"
            value={stockSymbol}
            onChange={this.handleInputChange}
          />
          <div className="input-group-append">
            <button className="btn btn-primary" type="button" onClick={this.handleSearch}>
              Search
            </button>
          </div>
        </div>
        <div className="mb-3">
          <label htmlFor="uncontrolledInput">Uncontrolled Input (Previous Searches):</label>
          <input
            type="text"
            className="form-control"
            id="uncontrolledInput"
            ref={this.stockSymbolInput}
            readOnly
          />
        </div>
        {stockPrice !== null && (
          <div className="alert alert-info">
            <strong>{stockSymbol}:</strong> ${stockPrice.toFixed(2)}
          </div>
        )}
        <div>
          <h2>Previous Searches</h2>
          <ul>
            {previousSearches.map((search, index) => (
              <li key={index}>{search}</li>
            ))}
          </ul>
        </div>
        {receivedData && (
          <div className="alert alert-warning">
            <strong>Received Data (Debug):</strong>
            <pre>{JSON.stringify(receivedData, null, 2)}</pre>
          </div>
        )}
      </div>
    );
  }
}

export default StockDashboard;