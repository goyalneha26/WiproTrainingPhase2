// server.js (Example with a delay)
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const axios = require('axios');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
      origin: "http://localhost:3000",
      methods: ["GET", "POST"]
    }
});

const PORT = 5000;
const requestQueue = [];
let isProcessing = false;

async function processQueue() {
  if (isProcessing || requestQueue.length === 0) return;
  isProcessing = true;
  const { symbol, socket } = requestQueue.shift();

  try {
    const response = await axios.get(`https://query1.finance.yahoo.com/v8/finance/chart/${symbol}`);
    const price = response.data.chart.result[0].meta.regularMarketPrice;
    socket.emit('stockUpdate', { symbol, price });
    await new Promise(resolve => setTimeout(resolve, 2000)); // Delay of 2 seconds
  } catch (error) {
    console.error('Error fetching stock data:', error);
    socket.emit('stockUpdate', {symbol: symbol, price: null})
  } finally {
    isProcessing = false;
    processQueue();
  }
}

io.on('connection', (socket) => {
  console.log('New client connected');

  socket.on('getStockPrice', (symbol) => {
    requestQueue.push({ symbol, socket });
    processQueue();
  });

  socket.on('disconnect', () => {
    console.log('Client disconnected');
  });
});

server.listen(PORT, () => console.log(`Server running on port ${PORT}`));